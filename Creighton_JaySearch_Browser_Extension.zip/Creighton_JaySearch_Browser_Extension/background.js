// This event is fired when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
  // Context menu item that appears when text is selected
  chrome.contextMenus.create({
    id: "searchCreightonJaySearch", // Unique identifier for the context menu item
    title: "Search on Creighton JaySearch", // Text that appears in the context menu
    contexts: ["selection"] // Context menu item only when text is selected
  });
});

// This event is fired when the context menu item is clicked
chrome.contextMenus.onClicked.addListener((info, tab) => {
  // Check if the clicked item is our context menu item
  if (info.menuItemId === "searchCreightonJaySearch") {
    // Get the selected text
    const query = info.selectionText;
    // Ensure the query is properly encoded for use in a URL
    const encodedQuery = encodeURIComponent(query);
    // Construct the search URL using the encoded query
    const searchUrl = `https://creighton.primo.exlibrisgroup.com/discovery/search?query=any,contains,${encodedQuery}&tab=Everything&search_scope=MyInst_and_CI&vid=01CRU_INST:01CRU&offset=0`; 
    // Open a new tab with the search URL
    chrome.tabs.create({ url: searchUrl });
  }
});

  